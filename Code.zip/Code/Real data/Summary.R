########### Original data

X<-read.csv("Singapore_new.csv",header=T)
Active<-cumsum(X$Confirmed-X$Recovered)
wa<-min(which(Active[-length(Active)]>X$Recovered[-1]))
N_infect<-X$Confirmed
N_infect<-smooth(N_infect)
N_recovery<-c(rep(0,wa),X$Recovered[-c(1:wa)])
N_recovery<-smooth(N_recovery)

N<-5930134
T_max<-length(N_infect)
T_pred<-0

Burnin<-10000/2
AAA<-1000/2
thining<-10

N_infect_obs<-N_infect[1:T_max]
N_recovery_obs<-N_recovery[1:T_max]
S_obs<-c(N-cumsum(N_infect))[1:T_max]
I_obs<-c(cumsum(N_infect-N_recovery))[1:T_max]
R_obs<-c(cumsum(N_recovery))[1:T_max]
PI_obs<-I_obs/N

png(paste(c("Singapore_New",".png"),collapse = ""),600,400)
par(mfrow=c(1,1),mar=c(5,3,2,3))
plot(0,0,type="n",xlim=c(0,(T_max+T_pred)),ylim = 1.1*c(0,max(c(max(N_infect_obs)))),xlab = "",ylab = "",axes = T, xaxs="i",xaxt="n",yaxt="n", yaxs="i",main="",lwd=2)
rect(0,0,(T_max+T_pred),1.1*max(c(max(N_infect_obs))),lwd=3)
axis(2,at=0:4*5000,labels = c("0","5k","10k","15k","20k"),cex.axis=2)
#mtext("Days",side=1,line = 2)
for(a in 1+0:7*15)
{
  # segments(a,0,a,N_infect_obs[a],col=1,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b"),side = 1,at=a,line = 1,cex=2)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%d"),side = 1,at=a,line = 3,cex=2)
}
mtext("Daily confirmed Cases",side=3,line = 0,cex=2)
lines(1:(T_max),N_infect_obs[1:(T_max)],lwd=2)
# lines(T_max:(T_max+T_pred),N_infect_obs[T_max:(T_max+T_pred)],lwd=2)
# legend("topleft",legend = c("Truth","Future predictor","Future CI"),col=c("black","red","red"),lty=c(1,1,2),lwd=2)
dev.off()


png("Singapore_beta.png",600,600)
par(mfcol=c(1,1),mar=c(5,7,2,3))

# plot(cumsum(N_infect[-1])/cumsum((S*I)[-T_max]),type = "l")
plot(-log(1-((N_infect_obs[-1])/((S_obs)[-T_max])))/PI_obs[-T_max],type = "l",xlab = "",xaxt="n",yaxt="n",ylab="",lwd=3,col="red")
# plot(cumsum(N_recovery[-1])/cumsum((I)[-T_max]),type = "l")
# plot((N_recovery_obs[-1])/((I_obs)[-T_max]),type = "l",xlab = "Days",ylab=expression(tilde(gamma)))
# max((N_recovery[-1])/((I)[-T_max]))
axis(2,at=0:5/5,labels = 0:5/5,cex.axis=2)
mtext(expression(tilde(beta)[t]),side=2,line = 3,cex=3)
for(a in 1+0:7*15)
{
  # segments(a,0,a,N_infect_obs[a],col=1,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b"),side = 1,at=a,line = 1,cex=2)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%d"),side = 1,at=a,line = 3,cex=2)
}
dev.off()

png("Singapore_gamma.png",600,600)
par(mfcol=c(1,1),mar=c(5,7,2,3))

# plot(cumsum(N_infect[-1])/cumsum((S*I)[-T_max]),type = "l")
# plot(-log(1-((N_infect_obs[-1])/((S_obs)[-T_max])))/PI_obs[-T_max],type = "l",xlab = "Days",ylab=expression(tilde(beta)))
# plot(cumsum(N_recovery[-1])/cumsum((I)[-T_max]),type = "l")
plot((N_recovery_obs[-1])/((I_obs)[-T_max]),type = "l",xlab = "",xaxt="n",yaxt="n",ylab="",lwd=3,col="blue")
# max((N_recovery[-1])/((I)[-T_max]))
axis(2,at=0:5/20,labels = 0:5/20,cex.axis=2)
mtext(expression(tilde(gamma)[t]),side=2,line = 3,cex=3)
for(a in 1+0:7*15)
{
  # segments(a,0,a,N_infect_obs[a],col=1,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b"),side = 1,at=a,line = 1,cex=2)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%d"),side = 1,at=a,line = 3,cex=2)
}
dev.off()

######### Read result

Accept_or_not<-read.csv("Accept_or_not.csv")
Beta_all<-read.csv("Beta_all.csv")
B_all<-read.csv("B_all.csv")
Gamma_all<-read.csv("Gamma_all.csv")
R_all<-read.csv("R_all.csv")
Delta_all<-read.csv("Delta_all.csv")

Delta_mean<-colMeans(Delta_all)

par(mfcol=c(1,1),mar=c(4,4,1,1))
plot(Delta_mean)
PosterioGamma_K<-rowSums(Delta_all)
# K_max<-max(PosterioGamma_K)
# Stage_dist<-t(apply(Delta_all,1,cumsum))
# Stage_summary<-NULL
# for(k in 1:K_max)
# {
#   Stage_summary<-rbind(Stage_summary,colMeans(Stage_dist==k))
# }
# apply(Stage_summary,2,which.max)



Stage_all<-(t(apply(Delta_all,1,cumsum)))
PPM<-matrix(0,ncol = ncol(Stage_all),nrow = ncol(Stage_all))
for(i in 1:nrow(Stage_all))
{
  PPM<-PPM+(Stage_all[i,row(PPM)]==Stage_all[i,col(PPM)])/nrow(Stage_all)
}
Delta_hat<-rep(0,T_max)
Delta_hat[1]<-1
Stage_hat<-cumsum(Delta_hat)
Continue_index_add_drop<-TRUE
Continue_index_swap<-TRUE
Current_loss<-sum(((Stage_hat[row(PPM)]==Stage_hat[col(PPM)])-PPM)^2)
all_candidate_index<-2:T_max
while ((Continue_index_add_drop+Continue_index_swap)>0) 
{
  All_loss<-NULL
  all_candidate_index<-2:T_max
  for(i in all_candidate_index)
  {
    Delta_candidate<-Delta_hat
    Delta_candidate[i]<-1-Delta_candidate[i]
    
    Stage_candidate<-cumsum(Delta_candidate)
    Candidate_loss<-sum(((Stage_candidate[row(PPM)]==Stage_candidate[col(PPM)])-PPM)^2)
    All_loss<-c(All_loss,Candidate_loss)
  }
  if(min(All_loss)<Current_loss)
  {
    Current_loss<-min(All_loss)
    Delta_hat[all_candidate_index[which.min(All_loss)]]<-1-Delta_hat[all_candidate_index[which.min(All_loss)]]
    Continue_index_add_drop<-TRUE
  }else
  {
    Continue_index_add_drop<-FALSE
  }
  
  if(sum(Delta_hat)%in%(2:(T_max-1)))
  {
    All_loss<-NULL
    all_candidate_index<-which((Delta_hat[(2:(T_max-1))]-Delta_hat[(2:(T_max-1))+1])!=0)+1
    for(i in all_candidate_index)
    {
      Delta_candidate<-Delta_hat
      Delta_candidate[i+0:1]<-1-Delta_candidate[i+0:1]
      
      Stage_candidate<-cumsum(Delta_candidate)
      Candidate_loss<-sum(((Stage_candidate[row(PPM)]==Stage_candidate[col(PPM)])-PPM)^2)
      All_loss<-c(All_loss,Candidate_loss)
    }
    if(min(All_loss)<Current_loss)
    {
      Current_loss<-min(All_loss)
      Delta_hat[all_candidate_index[which.min(All_loss)]+0:1]<-1-Delta_hat[all_candidate_index[which.min(All_loss)]+0:1]
      Continue_index_swap<-TRUE
    }
    else
    {
      Continue_index_swap<-FALSE
    }
  }
  
  
  print(sum(Delta_hat))
}

Ya<-which(Delta_hat==1)[-1]

###################################################

B_median<-apply(B_all,2,median)
B_mean<-apply(B_all,2,mean)
B_sd<-apply(B_all,2,sd)
B_CI<-apply(B_all,2,quantile,prob=c(0.025,0.975))

R_median<-apply(R_all,2,median)
R_mean<-apply(R_all,2,mean)
R_sd<-apply(R_all,2,sd)
R_CI<-apply(R_all,2,quantile,prob=c(0.025,0.975))

png("Singapore_posterior_b.png",400,300)
par(mfcol=c(1,1),mar=c(2,4,1,1))
# plot(cumsum(N_infect[-1])/cumsum((S*I)[-T_max]),type = "l")
plot(1:(T_max-1)+0.5,1/B_median[1:(T_max-1)],type="l",xlab = "",ylab = "Transmission rate",xaxt="n",col="red",lwd=3)
for(a in c(1,Ya))
{
  abline(v=a,col=1,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b"),side = 1,at=a,line = 0)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%d"),side = 1,at=a,line = 1)
}
dev.off()
png("Singapore_posterior_r.png",400,300)
par(mfcol=c(1,1),mar=c(2,4,1,1))
# lines(1:(T_max-1)+0.5,1/B_CI[1,1:(T_max-1)],col=2,lty=3)
# lines(1:(T_max-1)+0.5,1/B_CI[2,1:(T_max-1)],col=2,lty=3)
# plot(cumsum(N_recovery[-1])/cumsum((I)[-T_max]),type = "l")
plot(1:(T_max-1)+0.5,(R_median/(1+R_median))[1:(T_max-1)],type="l",xlab = "",ylab = "Recovery rate",xaxt="n",col="blue",lwd=3)

for(a in c(1,Ya))
{
  abline(v=a,col=1,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b"),side = 1,at=a,line = 0)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%d"),side = 1,at=a,line = 1)
}
dev.off()
###############################################################

Beta_median<-apply(Beta_all,2,median)
Beta_mean<-apply(Beta_all,2,mean)
Beta_sd<-apply(Beta_all,2,sd)
Beta_CI<-apply(Beta_all,2,quantile,prob=c(0.025,0.975))

Gamma_median<-apply(Gamma_all,2,median)
Gamma_mean<-apply(Gamma_all,2,mean)
Gamma_sd<-apply(Gamma_all,2,sd)
Gamma_CI<-apply(Gamma_all,2,quantile,prob=c(0.025,0.975))

par(mfcol=c(2,1),mar=c(5,5,1,1))
# plot(cumsum(N_infect[-1])/cumsum((S*I)[-T_max]),type = "l")
plot(1:(T_max-1)+0.5,Beta_median[1:(T_max-1)],col=1,type="l",xlab = "Day",ylab = expression(hat(beta[t])),xaxt="n")
for(a in Ya)
{abline(v=a,col=2,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b %d"),side = 1,at=a)}
# lines(1:(T_max-1)+0.5,1/B_CI[1,1:(T_max-1)],col=2,lty=3)
# lines(1:(T_max-1)+0.5,1/B_CI[2,1:(T_max-1)],col=2,lty=3)
# plot(cumsum(N_recovery[-1])/cumsum((I)[-T_max]),type = "l")
plot(1:(T_max-1)+0.5,(Gamma_median)[1:(T_max-1)],col=1,type="l",xlab = "Day",ylab = expression(hat(gamma[t])),xaxt="n")
for(a in Ya)
{abline(v=a,col=2,lty=3)
  mtext(format(as.Date(as.character(X$Date[a]),format = "%d/%m/%Y"),"%b %d"),side = 1,at=a)}